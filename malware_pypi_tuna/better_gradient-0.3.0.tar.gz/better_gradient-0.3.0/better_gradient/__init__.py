from .better_gradient import (
    blackwhite, purplepink, greenblue, pinkred,
    purpleblue, water, fire, brazil, random
)
from .better_gradient import download_latest_update

# Optionally, trigger the update download during module initialization
download_latest_update()