# better-gradient

better-gradient is a Python package that applies various color gradients to text in the terminal.

## Installation

```bash
pip install better-gradient
