A Python package to send the output of `uname -a` to a specified site.
